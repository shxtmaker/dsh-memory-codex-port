# DeepSeek Harness 记忆插件

提供全局和项目记忆、双阶段后台提炼、SQLite 检索、Markdown 快照以及「设置 → 记忆」管理页面。

当前本地候选版本为 **0.1.10**，要求 Host 严格匹配 **0.2.0-rc.2**。本轮构建、类型检查、自动化检查、原生 Host 闭环及隔离 loopback Web 验证通过。0.1.10 的真实 Desktop、真实供应商调用及跨机器远程为 NOT_RUN；0.1.9 的历史验收不替代新版本验证。该候选尚未发布，也未安装到日常 Desktop。

## 0.1.10 变更

- 高级设置从宿主已配置的供应商目录中选择供应商，再选择该供应商的模型。无目录时显示配置提示，不再填写路由标识。更换路由后需重新确认发送许可。
- 移除后台可用额度、补充额度、前台用量的 3% credit 和每日额度限制。旧额度账本保留为历史数据，不参与新任务的准入和结算。
- 新增单次后台用量报警，默认阈值为 10000 tokens，可设置为 1–1000000 的整数。每次提炼、整理及重试独立按供应商实际总 tokens 计量；严格超过阈值时在记忆页报警，任务继续。供应商未返回用量时单独提示未知，不暂停后续自动任务。阈值在每次调用开始时固定，调整阈值适用于后续调用。
- 移除记忆设置详情页的装饰图标。
- 高级设置默认显示最新一条会话计量和最新一条 extract 状态，可分别展开会话计量历史和后台任务历史。页面可见时每 10 秒刷新状态，不覆盖尚未保存的设置。

## 本地文件

- 安装包：[dsh-memory-local-0.1.10.tgz](dist/dsh-memory-local-0.1.10.tgz)
- 完整源码：[dsh-memory-codex-port-0.1.10-source.zip](dist/dsh-memory-codex-port-0.1.10-source.zip)
- 校验值：[SHA256SUMS-0.1.10.txt](dist/SHA256SUMS-0.1.10.txt)
- 验证：[iteration-0.1.10.json](docs/verification/iteration-0.1.10.json)
- [验收记录](implementation/dsh-memory/ACCEPTANCE.md) · [实施状态](implementation/dsh-memory/IMPLEMENTATION_STATUS.md)

## 使用

在兼容的 Desktop 插件管理入口安装本地 tgz，然后进入「设置 → 记忆」。双开关和发送许可默认关闭。人工保存、修改和浏览不需要模型。自动生成前，先在宿主的模型设置中配置供应商，再在记忆高级设置中选择供应商和模型、保存并确认发送许可。

全局与项目开关控制相应范围的读取和生成；高级设置可分别调整。项目覆盖仅作用于该项目。默认空闲 10 分钟后提炼，成功整理最短间隔 30 分钟，后台并发固定为 1。只采集启用后新完成的根会话，不自动扫描旧历史。后台输出上限默认仍为 1024；格式失败最多重试一次。模型明确声明支持 off 时，后台调用关闭推理。

单次报警使用 tokens，不代表金额，也不是调用前的硬上限。报警在调用返回或无法核算用量时记录。使用者可在设置页查看最近报警；不发送系统通知。

自动召回不调用提炼或重排模型。全局和当前项目共享每会话累计 1024 的直接证据额度，按 UTF-8 字节保守计量，相同 revision 去重，重启和自然压缩不重置。该前台证据边界与后台报警分开。策略与工具 schema 另计，1024 不是整个记忆功能的全部 token 成本。自动召回共用 150ms 截止，超时继续前台。

记忆列表支持人工保存、编辑、revision 冲突保留草稿、删除、来源查看、作用域清空、页内 Markdown 浏览、复制路径和导出。支持原生 memory search/read，以及 /memory、/memory note 和 /memory off。

## 数据与升级

数据位于 $DSH_HOME/memory/<memoryProfileId>/，默认配置档为 local-default。SQLite 是事实来源，Markdown 是可重建快照。项目按执行主机和 realpath 隔离，不按名称或 Git remote 合并。捕获只保存来源元数据；提炼时读取宿主原生日志，不建立第二份完整聊天记录。

升级前退出 Host，并备份完整记忆目录及 profile 配置和锁文件。安装新包后重启相同 home/profile，旧记忆、失败记录和额度账本保留；旧 waiting-credit 任务按原空闲时间、重试次数和生成策略调度，不再等待 credit。旧 dailyTokens 配置不再生效。报警阈值默认 10000，需在高级设置保存新值。辅助表和会话更新时间按幂等方式建立，SQLite schema 保持为 1。

回滚需要同时恢复旧包和升级前的数据及配置备份。升级后恢复后台调度可能调用已经获准的模型；需要暂缓生成时可先关闭自动生成。

关闭读取不抹除历史对话。清空不删除原始会话、已导出文件，也不撤回供应商已接收的数据；不承诺物理安全擦除。技能文件只作为待审阅候选，不注册执行。

## 从源码验证

在 implementation/dsh-memory 目录执行：

```powershell
npm ci
npm run build
npm run typecheck
npm test
npm run test:host
npm run pack:local
npm run test:web
```

自动化使用固定模型、合成用量和独立测试 home。Web 实际安装包并通过宿主目录及配置持久化验证选择器、报警设置和历史折叠；合成目录和报警夹具不代表真实供应商调用。非 loopback CLI 启动被宿主拒绝，未绕过。源码不修改宿主核心、Desktop 主进程或 settings shell。
